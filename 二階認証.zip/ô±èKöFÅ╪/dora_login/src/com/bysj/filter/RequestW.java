package com.bysj.filter;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


public class RequestW extends HttpServletRequestWrapper{
	HttpServletRequest request = null;
	public RequestW(HttpServletRequest request) {
		super(request);
		this.request=request;
		
	}
	
	@Override
	public String getParameter(String name) {
		String param=null;
		if("GET".equalsIgnoreCase(request.getMethod())){
			String p=request.getParameter(name);
			try {
			
			
				param = p==null?null:new String(p.getBytes("ISO-8859-1"),"UTF-8");
			
			
				 
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return param;
		}
		return request.getParameter(name);
	}

}
