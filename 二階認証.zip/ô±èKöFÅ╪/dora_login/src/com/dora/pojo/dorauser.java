package com.dora.pojo;

public class dorauser {
	private int eid;
	private String ename;
	private String password;
	private String googledouble;
	private String secret;
	

	public String getSecret() {
		return secret;
	}
	public void setSecret(String secret) {
		this.secret = secret;
	}
	public String getGoogledouble() {
		return googledouble;
	}
	public void setGoogledouble(String googledouble) {
		this.googledouble = googledouble;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public dorauser () {
		super();
	}
	
	public dorauser(String ename,String password){
		super();
		this.ename = ename;
		this.password = password;
	}
	
	public dorauser(String ename, String password, String googledouble) {
		super();
		this.ename = ename;
		this.password = password;
		this.googledouble = googledouble;
	}
	
	
	public dorauser(String ename, String password, String googledouble,
			String secret) {
		super();
		this.ename = ename;
		this.password = password;
		this.googledouble = googledouble;
		this.secret = secret;
	}
		

}
