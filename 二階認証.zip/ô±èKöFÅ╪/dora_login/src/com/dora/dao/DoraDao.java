package com.dora.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.dora.pojo.dorauser;
import com.dora.util.DBUtil;

public class DoraDao {
	public boolean loginuser(dorauser duser){
		String sql = "select * from user where ename= ? and password = ? ";
		Object[]param = {duser.getEname(),duser.getPassword()};
		DBUtil dbUtil = new DBUtil();
		dbUtil.getConnection();
		ResultSet rs = dbUtil.DataQuery(sql, param);
		
		try {
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		 
	}
	public int addUser(dorauser duser){
		String sql = "insert into user(ename,password,googledouble,secret)value(?,?,?,?)";
		Object[] param = {duser.getEname(),duser.getPassword(),duser.getGoogledouble(),duser.getSecret()
				};
		DBUtil dbUtil = new DBUtil();
		dbUtil.getConnection();
		int num = dbUtil.DataEdit(sql, param);
		if (num>0) {
			return num;
		}
		return num;
		
	}
	
	public String SelectSecret(dorauser duser){
		String sql = "select secret from user where ename = ? and password = ? ";
		Object[]param = {duser.getEname(),duser.getPassword()};
		DBUtil dbUtil = new DBUtil();
		dbUtil.getConnection();
		ResultSet rs = dbUtil.DataQuery(sql, param);
		
		try {
			if (rs.next()) {
				return rs.getString("secret");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		
		
		
	}
	

}
