package com.dora.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	
	public Connection getConnection(){
		String driverclass = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/dora";
		String user = "root";
		String password = "123456";
		
		try {
			Class.forName(driverclass);
			try {
				conn = DriverManager.getConnection(url, user, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	public ResultSet DataQuery(String sql,Object param [] ){
		try {
			psmt = conn.prepareStatement(sql);
			if (param!=null) {
				for (int i = 0; i < param.length; i++) {
					psmt.setObject(i+1, param[i]);
				}
			}
			rs = psmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	} 
	

	public int DataEdit(String sql,Object param [] ){
		int num = 0;
		try {
			psmt = conn.prepareStatement(sql);
			if (param!=null) {
				for (int i = 0; i < param.length; i++) {
					psmt.setObject(i+1, param[i]);
				}
			}
			num  = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return num;
	}
	
	
	public void CloseAll(){
		if (rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (psmt!=null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
  
}
