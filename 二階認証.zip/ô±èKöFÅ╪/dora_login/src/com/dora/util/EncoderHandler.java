package com.dora.util;
 

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import com.swetake.util.Qrcode;
  
  
public class EncoderHandler {  
      
    public static void encoderQRCoder(String content, HttpServletResponse response)throws Exception {  
       
            Qrcode qrcode = new Qrcode();  
            qrcode.setQrcodeErrorCorrect('M');  
            qrcode.setQrcodeEncodeMode('B');  
            qrcode.setQrcodeVersion(7);  
            
            String qrData = content; 
            
            //设置一下二维码的像素  
            int width =  67+12*(7-1);  
            int height = 67+12*(7-1);  
            
            BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
                       
          //绘图  
            Graphics2D gs = bufferedImage.createGraphics();  
            gs.setBackground(Color.WHITE);  
            gs.setColor(Color.BLACK);  
            gs.clearRect(0, 0, width, height);//清除下画板内容  
              
            //设置偏移量  不设置肯能导致解析出错  
            int pixoff = 2;  
            
            byte[] d = qrData.getBytes("utf-8");  
            if(d.length > 0 && d.length <120){  
                boolean[][] s = qrcode.calQrcode(d);  
                for(int i=0;i<s.length;i++){  
                    for(int j=0;j<s.length;j++){  
                        if(s[j][i]){  
                            gs.fillRect(j*3+pixoff, i*3+pixoff, 3, 3); 
                        }  
                    }  
                }  
            } 
              
            gs.dispose();  
            bufferedImage.flush();  
                            
            //生成二维码QRCode图片  
            ImageIO.write(bufferedImage, "png",response.getOutputStream());  
          

              
              
        }
}  