package com.dora.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dora.util.EncoderHandler;
import com.dora.util.GoogleAuthenticator;
  
public class CodeServlet extends HttpServlet {  
  
    private static final long serialVersionUID = 1L;  
      
    @Override  
    protected void service(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {   
    	request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String username = request.getParameter("ename");
		String secret = GoogleAuthenticator.generateSecretKey();
		String qrcode = GoogleAuthenticator.getQRBarcode(username, secret);
    	//HttpSession session = request.getSession();
    	//String content = (String) session.getAttribute("qrcode");
    	//String content = "otpauth://totp/user123?secret=NS6TUWOIMWCKPB5J";  
        EncoderHandler encoder = new EncoderHandler();  
        try {
			encoder.encoderQRCoder(qrcode, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
    }    
}  