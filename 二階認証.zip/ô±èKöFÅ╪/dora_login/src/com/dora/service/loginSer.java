package com.dora.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dora.dao.DoraDao;
import com.dora.pojo.dorauser;

public class loginSer extends HttpServlet{
	private static final long serialVersionUID = 1L;
	//private static String secret="FYTP52IWE2ZTB6NQ";

	public loginSer() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ename = request.getParameter("ename");
		String password = request.getParameter("password");
		//String googlepwd = request.getParameter("googlepwd");
		
		dorauser duser = new dorauser(ename,password);
		
		DoraDao doraDao = new DoraDao();
		
			if(doraDao.loginuser(duser)){
				request.setAttribute("ename", ename);
				request.setAttribute("password", password);
				request.getRequestDispatcher("googledouble.jsp").forward(request, response);
			}else {
				response.sendRedirect("login.jsp");
			}			
		
		
	}
	
	
	
}
