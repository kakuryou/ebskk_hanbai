package com.dora.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dora.dao.DoraDao;
import com.dora.pojo.dorauser;
import com.dora.util.GoogleAuthenticator;

public class registSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public registSer() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String username = request.getParameter("ename");
		String password = request.getParameter("password");
		
		String secret = GoogleAuthenticator.generateSecretKey();
		String qrcode = GoogleAuthenticator.getQRBarcode(username, secret);
		
		
		
		dorauser duser =new dorauser(username,password,qrcode,secret);
		DoraDao dao = new DoraDao();
		
		int num = dao.addUser(duser);
		
		if (num>0) {
			//EncoderHandler handler = new EncoderHandler();
	
				//handler.encoderQRCoder(qrcode, response);	
				//request.setAttribute("qrcode", qrcode);
				HttpSession session = request.getSession();
				session.setAttribute("qrcode", qrcode);
				request.getRequestDispatcher("index.jsp").forward(request, response);
		
			//response.getWriter().print(qrcode);
			//request.getRequestDispatcher("googledouble.jsp").forward(request, response);
		}else {
			response.getWriter().print("0");
			response.sendRedirect("regist.jsp");
		}
		
	}
	
	
	
	 
}
