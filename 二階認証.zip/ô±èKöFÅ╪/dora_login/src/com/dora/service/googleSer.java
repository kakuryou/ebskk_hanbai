package com.dora.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dora.dao.DoraDao;
import com.dora.pojo.dorauser;
import com.dora.util.GoogleAuthenticator;

public class googleSer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public googleSer() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ename = request.getParameter("ename");
		String password = request.getParameter("password");
		
		//request.getRequestDispatcher("/loginSer").forward(request, response);
		//String ename = request.getAttribute("ename").toString();
		//String password = request.getAttribute("password").toString();
		String googlepwd = request.getParameter("gpwd");
		System.out.println("ename"+ename);
		
		
		dorauser duser = new dorauser(ename,password);
		DoraDao dao = new DoraDao();
		
		String secret = dao.SelectSecret(duser);
		System.out.println("secret"+secret);
		
		long code = Long.valueOf(googlepwd);
		long t = System.currentTimeMillis();
		GoogleAuthenticator ga = new GoogleAuthenticator();
		ga.setWindowSize(5);
		boolean r = ga.check_code(secret, code, t);
		
		if (r) {
			request.getRequestDispatcher("success.jsp").forward(request, response);
		}else {
			response.getWriter().print("0");
			response.getWriter().print("tesr");
		}
		
	} 
	

}
