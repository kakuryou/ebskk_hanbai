function loginCheck(){
	var ename = document.getElementById("ename").value;
	var password = document.getElementById("password").value;
	alert("dssds");
	if (ename==null||ename=="") {
		alert("请输入用户名");
		document.getElementById("ename").focus();
	}
	else if (password == null||password =="") {
		alert("请输入密码");
		document.getElementById("password").focus();
	}
	else{
		document.getElementById("login").submit();
	}
	
}

/*$(function(){
	
	function checkeEname() {
		//获取员工编号
		var ename = $("#ename");
		//判断是否输入
		if (ename.val() == null || ename.val() == "") {
			alert("用户名不能为空!");
			//如果输入不符合,就返回false
			return false;
		}
		//否则返回true
		return true;
	}
	$("#login").submit(function() {
		

		var flag = true;
		if (!checkeEname()) flag = false;
		return flag;
	})
})*/