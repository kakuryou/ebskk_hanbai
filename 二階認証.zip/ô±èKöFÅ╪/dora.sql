/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : dora

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2018-04-09 13:34:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `eid` int(11) NOT NULL AUTO_INCREMENT,
  `ename` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `googledouble` varchar(100) DEFAULT NULL,
  `secret` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'dora1', '123', null, null);
INSERT INTO `user` VALUES ('2', 'zhangsan', '123', null, null);
INSERT INTO `user` VALUES ('3', 'lisi', '123', null, null);
INSERT INTO `user` VALUES ('4', 'df', '123', null, null);
INSERT INTO `user` VALUES ('5', 'qwer', '123', null, null);
INSERT INTO `user` VALUES ('6', 'qw', '123', null, null);
INSERT INTO `user` VALUES ('7', 'ebskk', '123', null, null);
INSERT INTO `user` VALUES ('8', 'ebs123', '123', null, null);
INSERT INTO `user` VALUES ('9', 'lixiaoc', 'ebs', null, null);
INSERT INTO `user` VALUES ('10', 'w', 'w', null, null);
INSERT INTO `user` VALUES ('11', '11', '11', 'otpauth://totp/11?secret=BMPYMDS2VU424C7Z', null);
INSERT INTO `user` VALUES ('12', '0', '0', 'otpauth://totp/0?secret=IWFQSKMUWYPDNXG7', null);
INSERT INTO `user` VALUES ('13', '3', '3', 'otpauth://totp/3?secret=TVLR3PFJPAYYX5AX', null);
INSERT INTO `user` VALUES ('14', 'lxc', '123', 'otpauth://totp/lxc?secret=OHVAJTZG23COIGSU', 'OHVAJTZG23COIGSU');
INSERT INTO `user` VALUES ('15', 'mike', '123', 'otpauth://totp/mike?secret=DMIZPAIZTKO7OIBW', 'DMIZPAIZTKO7OIBW');
INSERT INTO `user` VALUES ('16', 'w', 'w', 'otpauth://totp/w?secret=EJIEHFY4CSSYDFEW', 'EJIEHFY4CSSYDFEW');
INSERT INTO `user` VALUES ('17', 'w', 'w', 'otpauth://totp/w?secret=AL3ELFH7FABA2O4T', 'AL3ELFH7FABA2O4T');
INSERT INTO `user` VALUES ('18', 'w', 'w', 'otpauth://totp/w?secret=XOPH4ROIO7QLFWIV', 'XOPH4ROIO7QLFWIV');
INSERT INTO `user` VALUES ('19', 'w', 'w', 'otpauth://totp/w?secret=ACYA5SE7ZDAR76ZL', 'ACYA5SE7ZDAR76ZL');
INSERT INTO `user` VALUES ('20', 'w', 'w', 'otpauth://totp/w?secret=YWHTMX65MQRRF3UV', 'YWHTMX65MQRRF3UV');
INSERT INTO `user` VALUES ('21', 'w', 'w', 'otpauth://totp/w?secret=2CTNB5ZLOK7HHUFK', '2CTNB5ZLOK7HHUFK');
INSERT INTO `user` VALUES ('22', 'w', 'w', 'otpauth://totp/w?secret=AUBH62TFACGREQ5X', 'AUBH62TFACGREQ5X');
INSERT INTO `user` VALUES ('23', 'w', 'w', 'otpauth://totp/w?secret=WFIF4MOKJRIPLCXT', 'WFIF4MOKJRIPLCXT');
INSERT INTO `user` VALUES ('24', 'w', 'w', 'otpauth://totp/w?secret=RCTXAS4SCHLWVRG3', 'RCTXAS4SCHLWVRG3');
INSERT INTO `user` VALUES ('25', 'w', 'w', 'otpauth://totp/w?secret=G3BJA5XOKXSCXGU6', 'G3BJA5XOKXSCXGU6');
INSERT INTO `user` VALUES ('26', 'w', 'w', 'otpauth://totp/w?secret=QFZNJYO2FGMBPJOW', 'QFZNJYO2FGMBPJOW');
INSERT INTO `user` VALUES ('27', 'w', 'w', 'otpauth://totp/w?secret=DX7XVYJH35RBUEK7', 'DX7XVYJH35RBUEK7');
INSERT INTO `user` VALUES ('28', 'w', 'w', 'otpauth://totp/w?secret=PMH3RML4EVVA25KK', 'PMH3RML4EVVA25KK');
INSERT INTO `user` VALUES ('29', 'w', 'w', 'otpauth://totp/w?secret=PBLLBGP3TI32MROS', 'PBLLBGP3TI32MROS');
INSERT INTO `user` VALUES ('30', 'w', 'w', 'otpauth://totp/w?secret=ZIA2LWTD7D5NVEBA', 'ZIA2LWTD7D5NVEBA');
INSERT INTO `user` VALUES ('31', null, null, 'otpauth://totp/null?secret=V6SZLFSS6ZJBPKD2', 'V6SZLFSS6ZJBPKD2');
INSERT INTO `user` VALUES ('32', 'p', 'p', 'otpauth://totp/p?secret=KE6DNF5FFNKSB64C', 'KE6DNF5FFNKSB64C');
INSERT INTO `user` VALUES ('33', 'p', 'p', 'otpauth://totp/p?secret=CUOKWANGHAEL3N75', 'CUOKWANGHAEL3N75');
INSERT INTO `user` VALUES ('34', 'u', 'u', 'otpauth://totp/u?secret=A2I7E2QJTHMN43WX', 'A2I7E2QJTHMN43WX');
INSERT INTO `user` VALUES ('35', 'u', 'u', 'otpauth://totp/u?secret=ALO4N2LQ25ZI4XNZ', 'ALO4N2LQ25ZI4XNZ');
INSERT INTO `user` VALUES ('36', 'u', 'u', 'otpauth://totp/u?secret=WZGUBXUQZZAJC52V', 'WZGUBXUQZZAJC52V');
INSERT INTO `user` VALUES ('37', 'u', 'u', 'otpauth://totp/u?secret=PNDXNVB7D2JOCGEB', 'PNDXNVB7D2JOCGEB');
INSERT INTO `user` VALUES ('38', 'u', 'u', 'otpauth://totp/u?secret=XNIP2RIHGUZXFQDY', 'XNIP2RIHGUZXFQDY');
INSERT INTO `user` VALUES ('39', 'u', 'u', 'otpauth://totp/u?secret=ITLN2ER5TEHDU346', 'ITLN2ER5TEHDU346');
INSERT INTO `user` VALUES ('40', 'u', 'u', 'otpauth://totp/u?secret=B76EPE7KQ3ZMWST6', 'B76EPE7KQ3ZMWST6');
INSERT INTO `user` VALUES ('41', 'u', 'u', 'otpauth://totp/u?secret=IXIN3H2YFROV2XOE', 'IXIN3H2YFROV2XOE');
INSERT INTO `user` VALUES ('42', '1', '1', 'otpauth://totp/1?secret=YSPLNCGC3A3I7X3E', 'YSPLNCGC3A3I7X3E');
INSERT INTO `user` VALUES ('43', 'ccc', '123', 'otpauth://totp/ccc?secret=QRA6LMIURSAOYW5Q', 'QRA6LMIURSAOYW5Q');
INSERT INTO `user` VALUES ('44', '2', '2', 'otpauth://totp/2?secret=A4MTK4ZPEJQDI6IG', 'A4MTK4ZPEJQDI6IG');
INSERT INTO `user` VALUES ('45', 'tom', '123', 'otpauth://totp/tom?secret=YR4STJX4HMV4CJQH', 'YR4STJX4HMV4CJQH');
INSERT INTO `user` VALUES ('46', null, null, 'otpauth://totp/null?secret=MXCCQ2HAEAUDBP2L', 'MXCCQ2HAEAUDBP2L');
INSERT INTO `user` VALUES ('47', 'ol', '123', 'otpauth://totp/ol?secret=6WKWWTZ45NVVNUOV', '6WKWWTZ45NVVNUOV');
INSERT INTO `user` VALUES ('48', 'yu', '123', 'otpauth://totp/yu?secret=QIDJJKJD674PB76O', 'QIDJJKJD674PB76O');
INSERT INTO `user` VALUES ('49', 'k', 'k', 'otpauth://totp/k?secret=ZRBDW7HIL3DCQGAJ', 'ZRBDW7HIL3DCQGAJ');
INSERT INTO `user` VALUES ('50', 'swewew', 's', 'otpauth://totp/swewew?secret=KBIHCJDBM7SCEODC', 'KBIHCJDBM7SCEODC');
INSERT INTO `user` VALUES ('51', 'ee', 'eee', 'otpauth://totp/ee?secret=32IUQJXVYEHGQINI', '32IUQJXVYEHGQINI');
INSERT INTO `user` VALUES ('52', '22222', '222', 'otpauth://totp/22222?secret=MGF5RVTNP2V3YJEM', 'MGF5RVTNP2V3YJEM');
INSERT INTO `user` VALUES ('53', 'qwq', 'wq', 'otpauth://totp/qwq?secret=45HOC5FBIHTS4LSI', '45HOC5FBIHTS4LSI');
INSERT INTO `user` VALUES ('54', 'qq', 'ww', 'otpauth://totp/qq?secret=4H54LBFCRU2BDKE3', '4H54LBFCRU2BDKE3');
INSERT INTO `user` VALUES ('55', 'ebskk', '123', 'otpauth://totp/ebskk?secret=MGNG46OEMPKU76CX', 'MGNG46OEMPKU76CX');
INSERT INTO `user` VALUES ('56', '22', '22', 'otpauth://totp/22?secret=7DULBXMO2BSCJ6TO', '7DULBXMO2BSCJ6TO');
INSERT INTO `user` VALUES ('57', 'omome', '123', 'otpauth://totp/omome?secret=CNKA6W7WIQLW5RWW', 'CNKA6W7WIQLW5RWW');
INSERT INTO `user` VALUES ('58', 'plpe', '123', 'otpauth://totp/plpe?secret=QN5DBKO4GS63LB67', 'QN5DBKO4GS63LB67');
INSERT INTO `user` VALUES ('59', null, null, 'otpauth://totp/null?secret=4YVTAGCMQTXMHSOH', '4YVTAGCMQTXMHSOH');
INSERT INTO `user` VALUES ('60', 'qwqwqw', 'wqwq', 'otpauth://totp/qwqwqw?secret=SHCNVNIJF2FICRDE', 'SHCNVNIJF2FICRDE');
INSERT INTO `user` VALUES ('61', 'sdsd', '1212', 'otpauth://totp/sdsd?secret=ISGSAZQRWQW3PDD3', 'ISGSAZQRWQW3PDD3');
INSERT INTO `user` VALUES ('62', 'sdsd', 'dsds', 'otpauth://totp/sdsd?secret=T4KNU4EULIKE2ZAN', 'T4KNU4EULIKE2ZAN');
INSERT INTO `user` VALUES ('63', 'geg', '123', 'otpauth://totp/geg?secret=KHFPCDO2QVDFVPT7', 'KHFPCDO2QVDFVPT7');
INSERT INTO `user` VALUES ('64', null, null, 'otpauth://totp/null?secret=N6SOHVLD4W4OKOZZ', 'N6SOHVLD4W4OKOZZ');
INSERT INTO `user` VALUES ('65', null, null, 'otpauth://totp/null?secret=ZKB7AXGWULCQIGNB', 'ZKB7AXGWULCQIGNB');
INSERT INTO `user` VALUES ('66', 'bnm', '123', 'otpauth://totp/bnm?secret=UW7PSQ4WTDPZ6RFV', 'UW7PSQ4WTDPZ6RFV');
INSERT INTO `user` VALUES ('67', 'tetete', '123', 'otpauth://totp/tetete?secret=5NXEVRYLBUHPRGDY', '5NXEVRYLBUHPRGDY');
INSERT INTO `user` VALUES ('68', 'rwrw', '1231', 'otpauth://totp/rwrw?secret=3IBCAVXVYVO77EG7', '3IBCAVXVYVO77EG7');
INSERT INTO `user` VALUES ('69', '323', '2323', 'otpauth://totp/323?secret=F73THA33SMG4WWM7', 'F73THA33SMG4WWM7');
INSERT INTO `user` VALUES ('70', '2323', '23232', 'otpauth://totp/2323?secret=5ITBR7YZSSDWVXRT', '5ITBR7YZSSDWVXRT');
INSERT INTO `user` VALUES ('71', '434', '121', 'otpauth://totp/434?secret=3ZWCRZSNDSK6SH56', '3ZWCRZSNDSK6SH56');
INSERT INTO `user` VALUES ('72', '343', '43', 'otpauth://totp/343?secret=LOOEZU3S4DJU5UZM', 'LOOEZU3S4DJU5UZM');
INSERT INTO `user` VALUES ('73', '123', '12132', 'otpauth://totp/123?secret=O3W4QYOUBVWBVPHJ', 'O3W4QYOUBVWBVPHJ');
INSERT INTO `user` VALUES ('74', '3232', '2323', 'otpauth://totp/3232?secret=Q4TGK7OE6LGOFZLR', 'Q4TGK7OE6LGOFZLR');
INSERT INTO `user` VALUES ('75', '233', '32', 'otpauth://totp/233?secret=QT7DKNIGMDMVEWPH', 'QT7DKNIGMDMVEWPH');
INSERT INTO `user` VALUES ('76', 'gfefe', '1212', 'otpauth://totp/gfefe?secret=MW5HPL3PTSCHAQYG', 'MW5HPL3PTSCHAQYG');
INSERT INTO `user` VALUES ('77', 'wewe', '123', 'otpauth://totp/wewe?secret=NQA37XH5IQT2KJ34', 'NQA37XH5IQT2KJ34');
INSERT INTO `user` VALUES ('78', 'wewew', 'wewewe', 'otpauth://totp/wewew?secret=JLBUYB5SZGW56FPP', 'JLBUYB5SZGW56FPP');
INSERT INTO `user` VALUES ('79', 'wq', '12231233213133', 'otpauth://totp/wq?secret=XL47AW7QMGO7TM6V', 'XL47AW7QMGO7TM6V');
INSERT INTO `user` VALUES ('80', '212', '211', 'otpauth://totp/212?secret=HFJ6LAUZPQLCXJMO', 'HFJ6LAUZPQLCXJMO');
INSERT INTO `user` VALUES ('81', 'wew', 'ewew', 'otpauth://totp/wew?secret=KH32UN3IDAZLNS5V', 'KH32UN3IDAZLNS5V');
INSERT INTO `user` VALUES ('82', 'w323', '23', 'otpauth://totp/w323?secret=DXBVJBJEI5K6NQHM', 'DXBVJBJEI5K6NQHM');
INSERT INTO `user` VALUES ('83', '34', '34', 'otpauth://totp/34?secret=DCI3MPZZ65CU7WQ6', 'DCI3MPZZ65CU7WQ6');
INSERT INTO `user` VALUES ('84', '23', '32123124134', 'otpauth://totp/23?secret=J6ZEZTTCAU2KK7CK', 'J6ZEZTTCAU2KK7CK');
INSERT INTO `user` VALUES ('85', '2223', '222', 'otpauth://totp/2223?secret=U6XEVLHP7R4C3KUE', 'U6XEVLHP7R4C3KUE');
INSERT INTO `user` VALUES ('86', 'dsdsds', 'sdsd', 'otpauth://totp/dsdsds?secret=L7JUBPLAA465A4RB', 'L7JUBPLAA465A4RB');
INSERT INTO `user` VALUES ('87', 'ewewe', 'ewew', 'otpauth://totp/ewewe?secret=G7W5Z2RPDFU5TOBV', 'G7W5Z2RPDFU5TOBV');
INSERT INTO `user` VALUES ('88', null, null, 'otpauth://totp/null?secret=6GQOC5BCRVFLRAPE', '6GQOC5BCRVFLRAPE');
INSERT INTO `user` VALUES ('89', null, null, 'otpauth://totp/null?secret=OUDMISKQ63VP6PS2', 'OUDMISKQ63VP6PS2');
INSERT INTO `user` VALUES ('90', 'wewedsds', '122', 'otpauth://totp/wewedsds?secret=O3MQ3IFUBWMELE4F', 'O3MQ3IFUBWMELE4F');
INSERT INTO `user` VALUES ('91', '12345678', 'qwe', 'otpauth://totp/12345678?secret=Z6FN5FJ24E556E3O', 'Z6FN5FJ24E556E3O');
INSERT INTO `user` VALUES ('92', '232', '32323', 'otpauth://totp/232?secret=VYLHXJJGMROZ7LVR', 'VYLHXJJGMROZ7LVR');
INSERT INTO `user` VALUES ('93', '323', '12', 'otpauth://totp/323?secret=ZOAZYZ3YR4ESD7OP', 'ZOAZYZ3YR4ESD7OP');
INSERT INTO `user` VALUES ('94', 'wewewe', '122', 'otpauth://totp/wewewe?secret=3YY4DUJT35Q66U6V', '3YY4DUJT35Q66U6V');
INSERT INTO `user` VALUES ('95', '3232', '32', 'otpauth://totp/3232?secret=M3Q3N6CTFSJ4PVVE', 'M3Q3N6CTFSJ4PVVE');
INSERT INTO `user` VALUES ('96', '3232', '32323', 'otpauth://totp/3232?secret=UVSHVI6TQKZ2XW4Q', 'UVSHVI6TQKZ2XW4Q');
INSERT INTO `user` VALUES ('97', 'dsd', '111', 'otpauth://totp/dsd?secret=I7DXAHBVKBTQQ32U', 'I7DXAHBVKBTQQ32U');
INSERT INTO `user` VALUES ('98', '22', '22', 'otpauth://totp/22?secret=S5LM33JNLUMDVSO6', 'S5LM33JNLUMDVSO6');
INSERT INTO `user` VALUES ('99', '323', '232', 'otpauth://totp/323?secret=ZINQ7V4XYJS7SZVJ', 'ZINQ7V4XYJS7SZVJ');
INSERT INTO `user` VALUES ('100', '323', '232', 'otpauth://totp/323?secret=5FGZCEC33FMNU2JA', '5FGZCEC33FMNU2JA');
INSERT INTO `user` VALUES ('101', '3232', '3232', 'otpauth://totp/3232?secret=KSWLF5RMGIH4BS7G', 'KSWLF5RMGIH4BS7G');
INSERT INTO `user` VALUES ('102', '21212131312312312', '242', 'otpauth://totp/21212131312312312?secret=S22RSOIJRJRDC63D', 'S22RSOIJRJRDC63D');
INSERT INTO `user` VALUES ('103', '2323', '323', 'otpauth://totp/2323?secret=YVDWHMF5X424L2O7', 'YVDWHMF5X424L2O7');
INSERT INTO `user` VALUES ('104', '2323', '[[', 'otpauth://totp/2323?secret=OEVHZ7E3ER4USVHX', 'OEVHZ7E3ER4USVHX');
INSERT INTO `user` VALUES ('105', 'ewew', 'ew', 'otpauth://totp/ewew?secret=MXK3FSN3PXS3OBO6', 'MXK3FSN3PXS3OBO6');
INSERT INTO `user` VALUES ('106', 'ebs123', '123', 'otpauth://totp/ebs123?secret=A5RGYKLTE52OEFY3', 'A5RGYKLTE52OEFY3');
INSERT INTO `user` VALUES ('107', 'www', 'www', 'otpauth://totp/www?secret=AYP6D7KASZRE27H7', 'AYP6D7KASZRE27H7');
INSERT INTO `user` VALUES ('108', 'www', 'www', 'otpauth://totp/www?secret=YGENJL7ATS4NVTEI', 'YGENJL7ATS4NVTEI');
INSERT INTO `user` VALUES ('109', 'www', 'www', 'otpauth://totp/www?secret=TCYZAIVWM2EY2ZUO', 'TCYZAIVWM2EY2ZUO');
INSERT INTO `user` VALUES ('110', 'www', 'www', 'otpauth://totp/www?secret=Y5NYVWWNPEMGN6A5', 'Y5NYVWWNPEMGN6A5');
INSERT INTO `user` VALUES ('111', '2121', '21212', 'otpauth://totp/2121?secret=TE6QN5VZELZ3R3QN', 'TE6QN5VZELZ3R3QN');
INSERT INTO `user` VALUES ('112', 'qweq', '12313', 'otpauth://totp/qweq?secret=EV4PY7LOWRKPBRE6', 'EV4PY7LOWRKPBRE6');
INSERT INTO `user` VALUES ('113', 'qqq', 'qqq', 'otpauth://totp/qqq?secret=KOXMEHCW2FOMCWAI', 'KOXMEHCW2FOMCWAI');
INSERT INTO `user` VALUES ('114', 'qw', 'qwqw', 'otpauth://totp/qw?secret=JVJMVWURM7CA4WYH', 'JVJMVWURM7CA4WYH');
INSERT INTO `user` VALUES ('115', 'qw', 'qwqw', 'otpauth://totp/qw?secret=23DUWI2ZWUZXIGOX', '23DUWI2ZWUZXIGOX');
INSERT INTO `user` VALUES ('116', 'qw', 'qwqw', 'otpauth://totp/qw?secret=HEINEDVTKHN3RORP', 'HEINEDVTKHN3RORP');
INSERT INTO `user` VALUES ('117', 'qw', 'qwqw', 'otpauth://totp/qw?secret=N2P4JIR6QZE753B2', 'N2P4JIR6QZE753B2');
INSERT INTO `user` VALUES ('118', 'qw', 'qwqw', 'otpauth://totp/qw?secret=BPLIZVFZLMPW2MAJ', 'BPLIZVFZLMPW2MAJ');
INSERT INTO `user` VALUES ('119', 'ertrere', '23231', 'otpauth://totp/ertrere?secret=Z3KZIZYOAHGW37FP', 'Z3KZIZYOAHGW37FP');
INSERT INTO `user` VALUES ('120', 'ertrere', '23231', 'otpauth://totp/ertrere?secret=3ZTOQIB5PA4BXUDM', '3ZTOQIB5PA4BXUDM');
INSERT INTO `user` VALUES ('121', '33', '1111', 'otpauth://totp/33?secret=MVARZXJI3APVOV7K', 'MVARZXJI3APVOV7K');
INSERT INTO `user` VALUES ('122', '22', '222', 'otpauth://totp/22?secret=E7IVCCYMSMRUMBCH', 'E7IVCCYMSMRUMBCH');
INSERT INTO `user` VALUES ('123', '、、来了、', '怕【p', 'otpauth://totp/、、来了、?secret=6KH4TTEM4ZIZOOPI', '6KH4TTEM4ZIZOOPI');
INSERT INTO `user` VALUES ('124', 'ewe', 'ewew', 'otpauth://totp/ewe?secret=LAASKBITTTFOPYBA', 'LAASKBITTTFOPYBA');
INSERT INTO `user` VALUES ('125', 'lxc', '123', 'otpauth://totp/lxc?secret=JHI5HQT5OGEKS4VI', 'JHI5HQT5OGEKS4VI');
